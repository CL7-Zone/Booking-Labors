package com.example.bookinglabor.controller.component;

abstract public class ConstantComponent {

    public static final String vonageApiKey = "91e2e292";
    public static final String vonageApiSecret = "r9joEfQT0fRiGulE";

}
