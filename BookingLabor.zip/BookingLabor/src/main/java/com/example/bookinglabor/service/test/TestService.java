package com.example.bookinglabor.service.test;

public interface TestService {



}
