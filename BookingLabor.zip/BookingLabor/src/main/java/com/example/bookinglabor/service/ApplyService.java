package com.example.bookinglabor.service;

import com.example.bookinglabor.model.Apply;
import com.example.bookinglabor.repo.ApplyRepo;

import java.util.List;

public interface ApplyService extends ApplyRepo {


}
