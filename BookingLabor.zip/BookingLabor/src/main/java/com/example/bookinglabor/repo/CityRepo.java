package com.example.bookinglabor.repo;


import com.example.bookinglabor.model.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepo extends JpaRepository<City, Long> {




}
