package com.example.bookinglabor.controller.component;


import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Setter
@Getter
@Component
public class Tcomponent {


    private final String token;

    public Tcomponent() {
        this.token = "yKYt_KLRSPS5QhqDJWDrUV_01ZNWq0zXHmUYXvmnmIDd_-0Oxgk8fz2OmE6sV65r";
    }


}
