package com.example.bookinglabor.repo;

import com.example.bookinglabor.model.CommentSkill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentSkillRepo extends JpaRepository<CommentSkill,Long> {



}
