package com.example.bookinglabor.service;

public interface VonageSendSmsService {


    void sendSms(String phoneNumber, String messageBody);

}
