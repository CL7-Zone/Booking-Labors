package com.example.bookinglabor.service;

public interface CountService{

    int LoadCount();

}
