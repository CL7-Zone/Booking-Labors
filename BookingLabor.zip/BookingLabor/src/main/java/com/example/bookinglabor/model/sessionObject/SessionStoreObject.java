package com.example.bookinglabor.model.sessionObject;

import java.io.Serial;
import java.io.Serializable;

public class SessionStoreObject implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;


}
