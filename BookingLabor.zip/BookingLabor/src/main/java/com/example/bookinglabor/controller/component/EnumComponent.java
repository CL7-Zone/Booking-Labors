package com.example.bookinglabor.controller.component;

public enum EnumComponent {
    SIMPLE, GOOGLE, AUTH, isACTIVE, LOCKED


}
