package com.example.bookinglabor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingLaborApplicationTests {

    @Test
    void contextLoads() {
    }

}
