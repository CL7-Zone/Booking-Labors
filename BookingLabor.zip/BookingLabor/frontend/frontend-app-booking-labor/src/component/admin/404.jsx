import Unauthorized from "../element/Unauthorized";
import React from "react";

const Error = () => {


    return <Unauthorized />;
}

export default Error