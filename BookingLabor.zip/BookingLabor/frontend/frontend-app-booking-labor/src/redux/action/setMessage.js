export const setMessage = (msg) => ({
    type: "SET_MESSAGE",
    message: msg,
});

export const setToken = (token) => ({
    type: "SET_TOKEN",
    token: token,
});


export const setMsgSuccess = (messageSuccess) => ({
    type: "SET_MESSAGE_SUCCESS",
    messageSuccess: messageSuccess,
});













